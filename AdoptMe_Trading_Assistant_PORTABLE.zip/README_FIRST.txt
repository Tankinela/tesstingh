ADOPT ME TRADING ASSISTANT — PORTABLE WINDOWS VERSION

HOW TO RUN
1. Extract the whole ZIP.
2. Double-click START_APP.bat.
3. On the FIRST launch only, it downloads and installs its own private Python
   runtime inside the app folder and installs the required libraries.
4. After that, START_APP.bat launches the app directly.

You do NOT need to install Python yourself and it does NOT add Python to your
Windows PATH.

IMPORTANT
- Internet is required for the first launch and for refreshing market data.
- Keep all extracted files together.
- Windows SmartScreen may ask for confirmation because this is a .bat launcher.
- The app is an external calculator; it does not inject into Roblox or automate trades.
