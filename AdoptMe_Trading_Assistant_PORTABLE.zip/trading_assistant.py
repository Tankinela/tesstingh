
import json
import math
import queue
import re
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from difflib import SequenceMatcher
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

STARPETS_URL = "https://starpets.gg/adopt-me"
ELVE_DATA_URL = "https://raw.githubusercontent.com/ironbabatekkral/adoptme-values/main/adoptme_values.json"

AGE_WORDS = {
    "newborn", "junior", "pre-teen", "teen", "post-teen", "full-grown",
    "reborn", "twinkle", "sparkle", "flare", "sunshine", "luminous"
}
POTION_KEYS = {"NP":"no_potion","R":"ride","F":"fly","FR":"fly_ride"}

def normalize_name(name):
    s = name.lower().strip()
    for w in AGE_WORDS:
        s = re.sub(rf"\b{re.escape(w)}\b", " ", s, flags=re.I)
    s = re.sub(r"\bmega\s*neon\b|\bneon\b|\b(flyable|rideable|fly|ride)\b", " ", s, flags=re.I)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " ".join(s.split())

def fuzzy_best(name, choices):
    n = normalize_name(name)
    if n in choices: return n, 1.0
    best = ("", 0.0)
    for c in choices:
        score = SequenceMatcher(None, n, c).ratio()
        if score > best[1]: best = (c, score)
    return best

def extract_price(text):
    m = re.search(r"(\d+(?:\.\d+)?)\s*\$", text) or re.search(r"\$\s*(\d+(?:\.\d+)?)", text)
    return float(m.group(1)) if m else None

def session():
    s = requests.Session()
    s.headers.update({
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36",
        "Accept-Language":"en-US,en;q=0.9"
    })
    return s

def load_elve_values():
    r = session().get(ELVE_DATA_URL, timeout=30)
    r.raise_for_status()
    data = r.json()
    return {normalize_name(x["name"]): x for x in data if x.get("type") == "pets"}

def get_value(item, form, potion):
    block = item.get(form, {})
    v = block.get(POTION_KEYS.get(potion,"no_potion"))
    if v is None: v = block.get("value")
    try: return float(v)
    except: return None

def infer_variant_from_text(text):
    low = text.lower()
    form = "regular"
    if "mega" in low: form = "mega"
    elif "neon" in low or any(x in low for x in ["reborn","twinkle","sparkle","flare","sunshine","luminous"]): form = "neon"

    fly = bool(re.search(r"\bfly(?:able)?\b|\bfr\b|\bnfr\b|\bmfr\b", low))
    ride = bool(re.search(r"\bride(?:able)?\b|\bfr\b|\bnfr\b|\bmfr\b", low))
    if fly and ride: pot = "FR"
    elif fly: pot = "F"
    elif ride: pot = "R"
    else: pot = "NP"
    return form, pot

def parse_starpets(limit=400):
    r = session().get(STARPETS_URL, timeout=30)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    rows, seen = [], set()

    for a in soup.find_all("a", href=True):
        txt = " ".join(a.stripped_strings)
        price = extract_price(txt)
        if price is None or price <= 0: continue
        href = a["href"]
        if "adopt-me" not in href and "/shop/" not in href: continue

        name = re.sub(r"\s*\$?\s*\d+(?:\.\d+)?\s*\$?\s*$", "", txt).strip()
        if not name: continue
        url = urljoin("https://starpets.gg", href)
        form, pot = infer_variant_from_text(name)
        key = (name.lower(), form, pot)
        if key in seen: continue
        seen.add(key)
        rows.append({"raw_name":name, "price":price, "url":url, "form":form, "potion":pot})

    if not rows:
        text = soup.get_text(" ", strip=True)
        pat = re.compile(r"([A-Za-z0-9'’\- ]{2,80}?)\s+(\d+(?:\.\d+)?)\s*\$")
        for m in pat.finditer(text):
            name = " ".join(m.group(1).split())
            price = float(m.group(2))
            if price <= 0: continue
            form, pot = infer_variant_from_text(name)
            rows.append({"raw_name":name,"price":price,"url":"","form":form,"potion":pot})

    # cheapest listing per visible variant
    best = {}
    for row in rows:
        k = (normalize_name(row["raw_name"]), row["form"], row["potion"])
        if k not in best or row["price"] < best[k]["price"]:
            best[k] = row
    return sorted(best.values(), key=lambda x:x["price"])[:limit]

def match_market(star_rows, elve):
    choices = set(elve.keys())
    out = []
    for row in star_rows:
        key, sim = fuzzy_best(row["raw_name"], choices)
        if sim < 0.70: continue
        item = elve[key]
        val = get_value(item, row["form"], row["potion"])
        if not val or val <= 0: continue
        out.append({
            "name":item["name"], "price":row["price"], "value":val,
            "form":row["form"], "potion":row["potion"],
            "eff":val/row["price"], "similarity":sim, "url":row["url"]
        })
    # de-dupe exact canonical variants, keep cheapest price
    best = {}
    for x in out:
        k=(x["name"],x["form"],x["potion"])
        if k not in best or x["price"] < best[k]["price"]:
            best[k]=x
    return list(best.values())

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Adopt Me Trading Assistant — StarPets × Elvebredd")
        self.geometry("1380x820")
        self.minsize(1100,700)
        self.elve={}
        self.market=[]
        self.q=queue.Queue()
        self._build()
        self.after(150,self._poll)
        self._refresh()

    def _build(self):
        top=ttk.Frame(self,padding=10); top.pack(fill="x")
        ttk.Label(top,text="Adopt Me Trading Assistant",font=("Segoe UI",18,"bold")).pack(side="left")
        self.status=tk.StringVar(value="Loading…")
        ttk.Label(top,textvariable=self.status).pack(side="right")
        ttk.Button(top,text="Refresh",command=self._refresh).pack(side="right",padx=8)
        self.always=tk.BooleanVar(value=False)
        ttk.Checkbutton(top,text="Always on top",variable=self.always,
                        command=lambda:self.attributes("-topmost",self.always.get())).pack(side="right")

        self.nb=ttk.Notebook(self); self.nb.pack(fill="both",expand=True,padx=10,pady=(0,10))
        self.tab_deals=ttk.Frame(self.nb,padding=8)
        self.tab_flip=ttk.Frame(self.nb,padding=8)
        self.tab_trade=ttk.Frame(self.nb,padding=8)
        self.tab_offer=ttk.Frame(self.nb,padding=8)
        self.nb.add(self.tab_deals,text="🔥 Best Deals")
        self.nb.add(self.tab_flip,text="💸 Trade-Up Profit")
        self.nb.add(self.tab_trade,text="⚖ Trade Assistant")
        self.nb.add(self.tab_offer,text="🎯 Offer Finder")
        self._build_deals(); self._build_flip(); self._build_trade(); self._build_offer()

    def _build_deals(self):
        f=ttk.Frame(self.tab_deals); f.pack(fill="x",pady=(0,8))
        ttk.Label(f,text="Max USD:").pack(side="left")
        self.maxusd=tk.DoubleVar(value=999)
        ttk.Entry(f,textvariable=self.maxusd,width=8).pack(side="left",padx=5)
        ttk.Button(f,text="Filter",command=self._render_deals).pack(side="left",padx=5)
        ttk.Label(f,text="Higher Value/$ = more Elvebredd value for each $ spent.").pack(side="right")
        cols=("pet","form","pot","usd","value","eff")
        self.deal_tree=ttk.Treeview(self.tab_deals,columns=cols,show="headings")
        labels={"pet":"Pet","form":"Form","pot":"Potion","usd":"StarPets USD","value":"Elve value","eff":"Value / $"}
        widths={"pet":260,"form":90,"pot":80,"usd":120,"value":110,"eff":110}
        for c in cols:
            self.deal_tree.heading(c,text=labels[c]); self.deal_tree.column(c,width=widths[c],anchor="center" if c!="pet" else "w")
        self.deal_tree.pack(fill="both",expand=True)

    def _build_flip(self):
        f=ttk.Frame(self.tab_flip); f.pack(fill="x",pady=(0,8))
        ttk.Label(f,text="Max value difference:").pack(side="left")
        self.valdiff=tk.DoubleVar(value=5.0)
        ttk.Entry(f,textvariable=self.valdiff,width=7).pack(side="left",padx=5)
        ttk.Label(f,text="%   Min StarPets price gain:").pack(side="left")
        self.mingain=tk.DoubleVar(value=25.0)
        ttk.Entry(f,textvariable=self.mingain,width=7).pack(side="left",padx=5)
        ttk.Label(f,text="%").pack(side="left")
        ttk.Button(f,text="Find trade-ups",command=self._render_flips).pack(side="left",padx=10)

        ttk.Label(
            self.tab_flip,
            text="Idea: BUY cheap → TRADE for same/slightly higher Elve value → RECEIVE a pet that costs much more on StarPets."
        ).pack(anchor="w",pady=(0,8))

        cols=("buy","buyusd","buyval","target","targetusd","targetval","gain","vdiff")
        self.flip_tree=ttk.Treeview(self.tab_flip,columns=cols,show="headings")
        labels={
            "buy":"Buy on StarPets","buyusd":"Buy USD","buyval":"Buy value",
            "target":"Trade for","targetusd":"Target USD","targetval":"Target value",
            "gain":"Price gain","vdiff":"Value diff"
        }
        widths={"buy":240,"buyusd":90,"buyval":90,"target":240,"targetusd":95,"targetval":95,"gain":110,"vdiff":100}
        for c in cols:
            self.flip_tree.heading(c,text=labels[c]); self.flip_tree.column(c,width=widths[c],anchor="center" if c not in ("buy","target") else "w")
        self.flip_tree.pack(fill="both",expand=True)

    def _build_trade(self):
        ttk.Label(self.tab_trade,text="One pet per line: FR Frost Dragon / NFR Turtle / NP Owl").pack(anchor="w",pady=(0,8))
        p=ttk.Panedwindow(self.tab_trade,orient="horizontal"); p.pack(fill="both",expand=True)
        l=ttk.Labelframe(p,text="YOU GIVE",padding=8); r=ttk.Labelframe(p,text="YOU RECEIVE",padding=8)
        p.add(l,weight=1); p.add(r,weight=1)
        self.give=tk.Text(l,height=15); self.recv=tk.Text(r,height=15)
        self.give.pack(fill="both",expand=True); self.recv.pack(fill="both",expand=True)
        b=ttk.Frame(self.tab_trade); b.pack(fill="x",pady=10)
        ttk.Button(b,text="Calculate",command=self._calc_trade).pack(side="left")
        self.trade_result=tk.StringVar(value="")
        ttk.Label(b,textvariable=self.trade_result,font=("Segoe UI",13,"bold")).pack(side="left",padx=20)

    def _build_offer(self):
        f=ttk.Frame(self.tab_offer); f.pack(fill="x",pady=(0,8))
        ttk.Label(f,text="I have:").pack(side="left")
        self.offer_pet=tk.StringVar(value="FR Frost Dragon")
        ttk.Entry(f,textvariable=self.offer_pet,width=34).pack(side="left",padx=8)
        ttk.Label(f,text="Target +% value:").pack(side="left")
        self.offer_pct=tk.DoubleVar(value=3)
        ttk.Entry(f,textvariable=self.offer_pct,width=7).pack(side="left",padx=8)
        ttk.Button(f,text="Find offers",command=self._offers).pack(side="left")
        cols=("offer","value","usd","gain")
        self.offer_tree=ttk.Treeview(self.tab_offer,columns=cols,show="headings")
        for c,t,w in [("offer","Try asking for",500),("value","Elve value",110),("usd","StarPets USD",120),("gain","Value gain",110)]:
            self.offer_tree.heading(c,text=t); self.offer_tree.column(c,width=w,anchor="center" if c!="offer" else "w")
        self.offer_tree.pack(fill="both",expand=True)

    def _refresh(self):
        self.status.set("Refreshing StarPets + values…")
        threading.Thread(target=self._worker,daemon=True).start()

    def _worker(self):
        try:
            elve=load_elve_values()
            star=parse_starpets()
            market=match_market(star,elve)
            self.q.put(("data",(elve,market)))
            self.q.put(("status",f"Ready — {len(market)} matched variants"))
        except Exception as e:
            self.q.put(("error",str(e)))

    def _poll(self):
        try:
            while True:
                k,p=self.q.get_nowait()
                if k=="data":
                    self.elve,self.market=p
                    self._render_deals(); self._render_flips()
                elif k=="status": self.status.set(p)
                elif k=="error":
                    self.status.set("Refresh failed")
                    messagebox.showerror("Refresh error",p)
        except queue.Empty: pass
        self.after(150,self._poll)

    def label(self,x):
        prefix=("M" if x["form"]=="mega" else "N" if x["form"]=="neon" else "")
        pot="" if x["potion"]=="NP" else x["potion"]
        tag=(prefix+pot).strip() or "NP"
        return f"{tag} {x['name']}"

    def _render_deals(self):
        for i in self.deal_tree.get_children(): self.deal_tree.delete(i)
        maxu=float(self.maxusd.get())
        for x in sorted(self.market,key=lambda z:z["eff"],reverse=True):
            if x["price"]>maxu: continue
            self.deal_tree.insert("", "end", values=(
                x["name"],x["form"].upper(),x["potion"],f"${x['price']:.2f}",f"{x['value']:.2f}",f"{x['eff']:.2f}"
            ))

    def _render_flips(self):
        for i in self.flip_tree.get_children(): self.flip_tree.delete(i)
        if not self.market: return
        maxdiff=float(self.valdiff.get())/100
        mingain=float(self.mingain.get())/100
        results=[]
        m=self.market
        for buy in m:
            if buy["price"]<=0: continue
            for target in m:
                if target is buy: continue
                # target should have similar or slightly higher Elve value
                vdiff=(target["value"]-buy["value"])/buy["value"]
                if vdiff < -0.01 or vdiff > maxdiff:
                    continue
                pgain=(target["price"]-buy["price"])/buy["price"]
                if pgain < mingain:
                    continue
                # Score rewards huge StarPets price jump with minimal value jump
                score=pgain-(abs(vdiff)*0.8)
                results.append((score,buy,target,pgain,vdiff))
        results.sort(key=lambda z:z[0],reverse=True)
        seen=set()
        for _,buy,target,pgain,vdiff in results[:250]:
            k=(self.label(buy),self.label(target))
            if k in seen: continue
            seen.add(k)
            self.flip_tree.insert("", "end", values=(
                self.label(buy),f"${buy['price']:.2f}",f"{buy['value']:.2f}",
                self.label(target),f"${target['price']:.2f}",f"{target['value']:.2f}",
                f"+{pgain*100:.1f}%",f"{vdiff*100:+.1f}%"
            ))

    def _parse_query(self,s):
        raw=s.strip(); low=raw.lower()
        form="regular"
        if re.search(r"\bmfr\b|\bmega\b|\bmr\b|\bmf\b",low): form="mega"
        elif re.search(r"\bnfr\b|\bneon\b|\bnr\b|\bnf\b",low): form="neon"
        pot="NP"
        if re.search(r"\bmfr\b|\bnfr\b|\bfr\b",low): pot="FR"
        elif re.search(r"\bmr\b|\bnr\b|\br\b",low): pot="R"
        elif re.search(r"\bmf\b|\bnf\b|\bf\b",low): pot="F"
        cleaned=re.sub(r"\b(mfr|nfr|fr|mr|nr|mf|nf|np|mega|neon|ride|fly|no[\s-]*pot(?:ion)?)\b"," ",raw,flags=re.I)
        key,sim=fuzzy_best(cleaned,set(self.elve.keys()))
        if sim<.62:return None
        item=self.elve[key]; val=get_value(item,form,pot)
        if val is None:return None
        return {"name":item["name"],"form":form,"potion":pot,"value":val}

    def _sum(self,w):
        total=0; bad=[]
        for line in w.get("1.0","end").splitlines():
            if not line.strip():continue
            p=self._parse_query(line)
            if p: total+=p["value"]
            else: bad.append(line)
        return total,bad

    def _calc_trade(self):
        a,ba=self._sum(self.give); b,bb=self._sum(self.recv)
        if ba or bb: messagebox.showwarning("Unknown pet","Could not match:\n"+"\n".join(ba+bb))
        if a<=0: self.trade_result.set("Add pets to YOU GIVE"); return
        diff=b-a; pct=diff/a*100
        verdict="🟢 WIN" if pct>=5 else "🔴 LOSE" if pct<=-5 else "🟡 FAIR"
        self.trade_result.set(f"{verdict} | {a:.2f} → {b:.2f} | {diff:+.2f} ({pct:+.1f}%)")

    def _offers(self):
        for i in self.offer_tree.get_children():self.offer_tree.delete(i)
        p=self._parse_query(self.offer_pet.get())
        if not p: messagebox.showwarning("Pet","Couldn't match that pet."); return
        target=p["value"]*(1+float(self.offer_pct.get())/100)
        candidates=[]
        for x in self.market:
            if target<=x["value"]<=target*1.08:
                candidates.append((x["value"]-target,x))
        candidates.sort(key=lambda z:(z[0],-z[1]["price"]))
        for _,x in candidates[:40]:
            gain=x["value"]-p["value"]
            self.offer_tree.insert("", "end", values=(
                self.label(x),f"{x['value']:.2f}",f"${x['price']:.2f}",f"+{gain:.2f}"
            ))

if __name__=="__main__":
    App().mainloop()
