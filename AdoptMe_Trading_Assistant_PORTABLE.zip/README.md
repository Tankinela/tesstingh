# Adopt Me Trading Assistant

## Co umí
- StarPets ceny v **USD**
- Elvebredd-style values
- rozlišení NP / R / F / FR a Regular / Neon / Mega
- Best Deals = vysoká value za málo $
- Trade-Up Profit = koupíš levnějšího peta a hledá peta s podobnou nebo vyšší value, ale výrazně vyšší StarPets cenou
- Trade Assistant = WIN / FAIR / LOSE
- Offer Finder = navrhne cíl s mírně vyšší value

## Spuštění
1. Nainstaluj Python 3.11+.
2. Rozbal složku.
3. Dvojklik na `run.bat`.

## Důležité
Weby mohou měnit HTML/API. Když StarPets změní stránku, parser může potřebovat úpravu.
Program nic neposílá do Robloxu a neautomatizuje trady — funguje jako externí kalkulačka.

## Trade-Up Profit příklad
Když:
- Pet A stojí $2 a má value 20
- Pet B stojí $6 a má value 20.5

program ukáže přibližně:
`BUY Pet A → TRADE FOR Pet B → +200% StarPets price, +2.5% value`

To je přesně hledání cenového rozdílu mezi trhem StarPets a trade value.
