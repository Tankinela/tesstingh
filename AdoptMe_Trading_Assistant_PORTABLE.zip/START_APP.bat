@echo off
setlocal
cd /d "%~dp0"

set "PYDIR=%CD%\runtime"
set "PYEXE=%PYDIR%\python.exe"
set "PYWEXE=%PYDIR%\pythonw.exe"
set "INSTALLER=%CD%\python-installer.exe"

if exist "%PYEXE%" goto HAVE_PYTHON

echo.
echo ==========================================
echo  Adopt Me Trading Assistant - first setup
echo ==========================================
echo.
echo Downloading local Python runtime...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile '%INSTALLER%'"

if not exist "%INSTALLER%" (
    echo.
    echo ERROR: Python download failed.
    echo Check your internet connection and run START_APP.bat again.
    pause
    exit /b 1
)

echo Installing Python locally inside this folder...
"%INSTALLER%" /quiet InstallAllUsers=0 TargetDir="%PYDIR%" Include_pip=1 Include_tcltk=1 Include_test=0 Include_launcher=0 PrependPath=0 Shortcuts=0

if not exist "%PYEXE%" (
    echo.
    echo ERROR: Local Python installation failed.
    pause
    exit /b 1
)

del /q "%INSTALLER%" >nul 2>&1

:HAVE_PYTHON
if not exist "%CD%\.packages_ready" (
    echo Installing app libraries...
    "%PYEXE%" -m pip install --disable-pip-version-check -q -r "%CD%\requirements.txt"
    if errorlevel 1 (
        echo.
        echo ERROR: Package installation failed.
        pause
        exit /b 1
    )
    echo ready>"%CD%\.packages_ready"
)

echo Starting Trading Assistant...
start "" "%PYWEXE%" "%CD%\trading_assistant.py"
exit /b 0
