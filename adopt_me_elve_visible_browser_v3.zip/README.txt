V3
1. Close older V1/V2 server windows first.
2. Extract this ZIP.
3. Run START.bat.
4. Keep the black CMD window open.
5. A normal Chrome window will temporarily open Elvebredd while refreshing values.
6. Do not manually open index.html.
7. Local UI: http://127.0.0.1:8765/

If it fails, send a screenshot of the BLACK CMD window because V3 prints the exact extraction error there.
