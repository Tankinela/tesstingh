@echo off
title Adopt Me Elvebredd V3
cd /d "%~dp0"
echo Checking Selenium...
python -m pip install -q selenium
if errorlevel 1 (
 echo Selenium install failed.
 pause
 exit /b
)
echo Starting V3...
python server.py
echo.
echo Server stopped/crashed.
pause
