from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, time, threading, webbrowser

ROOT = Path(__file__).resolve().parent
CACHE = {"data": None, "time": 0, "error": None}

def browser_extract():
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.support.ui import WebDriverWait

    opts = Options()
    # IMPORTANT: visible Chrome, not headless.
    opts.add_argument("--window-size=1400,1000")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)

    driver = webdriver.Chrome(options=opts)
    try:
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": "Object.defineProperty(navigator,'webdriver',{get:()=>undefined})"
        })

        driver.get("https://elvebredd.com/adopt-me-calculator")
        WebDriverWait(driver, 30).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        time.sleep(6)

        # 1) Look through already-loaded browser resources.
        resources = driver.execute_script("""
          return performance.getEntriesByType('resource').map(x => x.name);
        """)
        candidates = [u for u in resources if "Pets.json" in u or "/data/" in u]

        # 2) Try extracting likely pet/value data already embedded in page globals / scripts.
        result = driver.execute_script("""
        function looksLikePet(x){
          return x && typeof x==='object' && typeof x.name==='string' &&
            (
              x.rvalue!==undefined || x.nvalue!==undefined || x.mvalue!==undefined ||
              x['rvalue - nopotion']!==undefined ||
              x['nvalue - nopotion']!==undefined ||
              x['mvalue - nopotion']!==undefined
            );
        }

        function findArrays(root, maxDepth=5){
          const seen=new WeakSet();
          const found=[];
          function walk(x,depth,path){
            if(!x || typeof x!=='object' || depth>maxDepth) return;
            if(seen.has(x)) return;
            seen.add(x);

            try{
              if(Array.isArray(x)){
                const good=x.filter(looksLikePet);
                if(good.length>=10) found.push({path, data:good});
                for(let i=0;i<Math.min(x.length,30);i++) walk(x[i],depth+1,path+'['+i+']');
              } else {
                for(const k of Object.keys(x).slice(0,150)){
                  let v;
                  try{v=x[k]}catch(e){continue}
                  walk(v,depth+1,path+'.'+k);
                }
              }
            }catch(e){}
          }

          walk(root,0,'window');
          found.sort((a,b)=>b.data.length-a.data.length);
          return found.length ? found[0] : null;
        }

        // Avoid walking the entire DOM/browser internals. Check common app globals first.
        const roots = [];
        for(const k of Object.keys(window)){
          if(/next|data|pet|elve|state|store|query/i.test(k)){
            try{
              const v=window[k];
              if(v && typeof v==='object') roots.push({k,v});
            }catch(e){}
          }
        }

        let best=null;
        for(const r of roots){
          const f=findArrays(r.v,4);
          if(f && (!best || f.data.length>best.data.length)){
            best={path:r.k+f.path.slice(6),data:f.data};
          }
        }
        return best;
        """)

        if result and result.get("data") and len(result["data"]) >= 10:
            return result["data"], "page memory: " + result.get("path","unknown")

        # 3) If the page itself loaded Pets.json successfully, retrieve its already-known URL
        # from within the visible, established page context.
        for url in candidates:
            if "Pets.json" not in url:
                continue
            fetched = driver.execute_async_script("""
                const url=arguments[0], done=arguments[1];
                fetch(url,{credentials:'include',cache:'force-cache'})
                  .then(async r=>done({ok:r.ok,status:r.status,text:await r.text()}))
                  .catch(e=>done({ok:false,error:String(e)}));
            """, url)
            if fetched.get("ok"):
                data=json.loads(fetched["text"])
                return data, "browser resource"

        # 4) Last resort: inspect visible page text for debugging.
        title=driver.title
        body=driver.find_element("tag name","body").text[:1000]
        raise RuntimeError(
            "The visible Elvebredd page opened, but pet data was not found in loaded page memory/resources. "
            "Title=%r Resources=%r Body=%r" % (title, candidates[:10], body[:300])
        )
    finally:
        time.sleep(1)
        driver.quit()

def refresh():
    try:
        data, source = browser_extract()
        CACHE["data"] = {"pets": data, "source": source}
        CACHE["time"] = time.time()
        CACHE["error"] = None
        print("SUCCESS:", source, "rows:", len(data) if hasattr(data,'__len__') else '?')
    except Exception as e:
        CACHE["error"] = str(e)
        print("ERROR:", repr(e))

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        rel=path.split("?",1)[0].split("#",1)[0].lstrip("/") or "index.html"
        return str(ROOT/rel)

    def send_json(self,status,obj):
        b=json.dumps(obj,ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith("/api/elve"):
            refresh()
            if CACHE["data"] is not None:
                self.send_json(200,CACHE["data"])
            else:
                self.send_json(502,{"error":CACHE["error"] or "Unknown error"})
            return
        super().do_GET()

def open_local():
    time.sleep(1)
    webbrowser.open("http://127.0.0.1:8765/")

if __name__=="__main__":
    os.chdir(ROOT)
    print("="*65)
    print("Adopt Me Elvebredd V3 - VISIBLE BROWSER EXTRACTOR")
    print("A normal Chrome window will open while values are refreshed.")
    print("Do not close it until extraction finishes.")
    print("="*65)
    threading.Thread(target=open_local,daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1",8765),Handler).serve_forever()
