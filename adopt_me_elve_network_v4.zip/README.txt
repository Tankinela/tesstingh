V4 - automatic network discovery

1. Close all previous V1/V2/V3 CMD windows.
2. Extract the ZIP.
3. Run START.bat.
4. A normal Chrome will open Elvebredd.
5. V4 automatically tries to search Frost Dragon and scans network responses.
6. If it finds the full value dataset, the table loads automatically.
7. If it fails, the folder will contain elve_discovery.json with candidate URLs/responses.

Do not open index.html directly.
