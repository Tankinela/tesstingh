@echo off
title Elvebredd Network Discovery V4
cd /d "%~dp0"
python -m pip install -q selenium
if errorlevel 1 (
 echo Selenium installation failed.
 pause
 exit /b
)
python server.py
echo.
echo Server stopped/crashed.
pause
