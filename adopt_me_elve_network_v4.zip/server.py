from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, time, threading, webbrowser, re

ROOT = Path(__file__).resolve().parent
CACHE = {"data": None, "source": None, "error": None, "candidates": []}

MARKERS = ["Frost Dragon", '"rvalue"', '"nvalue"', '"mvalue"', "rvalue - nopotion"]

def looks_like_dataset(obj):
    arr = obj if isinstance(obj, list) else list(obj.values()) if isinstance(obj, dict) else []
    good = 0
    for p in arr[:5000]:
        if isinstance(p, dict) and p.get("name") and (
            "rvalue" in p or "nvalue" in p or "mvalue" in p or
            "rvalue - nopotion" in p or "nvalue - nopotion" in p or "mvalue - nopotion" in p
        ):
            good += 1
            if good >= 10:
                return True
    return False

def try_json(text):
    text = text.strip()
    try:
        return json.loads(text)
    except:
        pass
    # Sometimes responses are wrapped.
    for left, right in [("[", "]"), ("{", "}")]:
        a, b = text.find(left), text.rfind(right)
        if a >= 0 and b > a:
            try:
                return json.loads(text[a:b+1])
            except:
                pass
    return None

def discover():
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys

    opts = Options()
    opts.add_argument("--window-size=1400,1000")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.set_capability("goog:loggingPrefs", {"performance": "ALL"})

    driver = webdriver.Chrome(options=opts)
    found = None
    candidates = []
    seen_request_ids = set()

    def harvest():
        nonlocal found
        logs = driver.get_log("performance")
        for entry in logs:
            try:
                msg = json.loads(entry["message"])["message"]
            except:
                continue
            if msg.get("method") != "Network.responseReceived":
                continue
            p = msg.get("params", {})
            rid = p.get("requestId")
            response = p.get("response", {})
            url = response.get("url", "")
            mime = response.get("mimeType", "")
            status = response.get("status", 0)
            if not rid or rid in seen_request_ids:
                continue
            seen_request_ids.add(rid)

            # Skip obvious images/fonts/media.
            if any(x in mime for x in ["image/", "font/", "video/", "audio/"]):
                continue

            try:
                body = driver.execute_cdp_cmd("Network.getResponseBody", {"requestId": rid}).get("body", "")
            except:
                continue

            if not body:
                continue

            hit = any(m.lower() in body.lower() for m in MARKERS)
            if hit or "/data/" in url.lower() or "pet" in url.lower() or "calculator" in url.lower():
                candidates.append({
                    "url": url,
                    "status": status,
                    "mime": mime,
                    "size": len(body),
                    "markers": [m for m in MARKERS if m.lower() in body.lower()],
                    "preview": body[:500]
                })

            obj = try_json(body)
            if obj is not None and looks_like_dataset(obj):
                found = (obj, url)
                return

    try:
        driver.execute_cdp_cmd("Network.enable", {})
        driver.get("https://elvebredd.com/adopt-me-calculator")
        time.sleep(7)
        harvest()
        if found:
            return found[0], found[1], candidates

        # Try to interact with the calculator search box.
        inputs = driver.find_elements(By.CSS_SELECTOR, "input")
        target = None
        for el in inputs:
            try:
                ph = (el.get_attribute("placeholder") or "").lower()
                typ = (el.get_attribute("type") or "").lower()
                if el.is_displayed() and ("search" in ph or "pet" in ph or typ in ("text","search","")):
                    target = el
                    break
            except:
                pass

        if target:
            try:
                target.click()
                target.clear()
                target.send_keys("Frost Dragon")
                time.sleep(2)

                # Click a visible exact-ish Frost Dragon suggestion if present.
                clicked = False
                els = driver.find_elements(By.XPATH, "//*[contains(translate(normalize-space(text()), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'frost dragon')]")
                for el in els:
                    try:
                        if el.is_displayed():
                            el.click()
                            clicked = True
                            break
                    except:
                        pass

                if not clicked:
                    target.send_keys(Keys.ARROW_DOWN)
                    target.send_keys(Keys.ENTER)

                time.sleep(5)
            except Exception as e:
                candidates.append({"interaction_error": str(e)})

        harvest()
        if found:
            return found[0], found[1], candidates

        # Search loaded script text from page for direct endpoints/markers as a final diagnostic.
        scripts = driver.find_elements(By.TAG_NAME, "script")
        for s in scripts:
            src = s.get_attribute("src") or ""
            if src and "_next/static/chunks" in src:
                candidates.append({"script": src})

        raise RuntimeError("No full pet-value dataset found automatically. See candidates in CMD / discovery JSON.")

    finally:
        driver.quit()

def refresh():
    try:
        data, source, candidates = discover()
        CACHE["data"] = data
        CACHE["source"] = source
        CACHE["candidates"] = candidates
        CACHE["error"] = None
        (ROOT/"elve_discovery.json").write_text(
            json.dumps({"source":source,"candidates":candidates}, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        print("SUCCESS DATASET:", source)
    except Exception as e:
        CACHE["data"] = None
        CACHE["source"] = None
        CACHE["error"] = str(e)
        try:
            (ROOT/"elve_discovery.json").write_text(
                json.dumps({"error":str(e),"candidates":CACHE["candidates"]}, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except:
            pass
        print("DISCOVERY ERROR:", repr(e))
        print("Candidate responses:")
        for c in CACHE.get("candidates", [])[:30]:
            print(c)

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        rel = path.split("?",1)[0].split("#",1)[0].lstrip("/") or "index.html"
        return str(ROOT / rel)

    def send_json(self,status,obj):
        b=json.dumps(obj,ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith("/api/discover"):
            refresh()
            if CACHE["data"] is not None:
                self.send_json(200, {"pets":CACHE["data"],"source":CACHE["source"]})
            else:
                self.send_json(502, {"error":CACHE["error"],"candidates":CACHE["candidates"]})
            return
        super().do_GET()

def open_local():
    time.sleep(1)
    webbrowser.open("http://127.0.0.1:8765/")

if __name__ == "__main__":
    os.chdir(ROOT)
    print("="*68)
    print("ELVEBREDD NETWORK DISCOVERY V4")
    print("This will open a normal Chrome, search Frost Dragon, and inspect")
    print("network responses for the real pet value dataset.")
    print("="*68)
    threading.Thread(target=open_local,daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1",8765), Handler).serve_forever()
