1) Extract the ZIP.
2) Make sure Google Chrome and Python are installed.
3) Double-click START.bat.
4) The first run installs Selenium automatically.
5) Keep the black window open.
6) Use the page at http://127.0.0.1:8765/

Do NOT open index.html directly.
