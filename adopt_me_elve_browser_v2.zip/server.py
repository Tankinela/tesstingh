from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, time, threading, webbrowser

ROOT = Path(__file__).resolve().parent
CACHE = {"data": None, "time": 0, "error": None}

def get_live_data():
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.support.ui import WebDriverWait

    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--window-size=1280,900")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36")

    driver = webdriver.Chrome(options=opts)
    try:
        # First establish a normal Elvebredd browser session.
        driver.get("https://elvebredd.com/adopt-me-calculator")
        time.sleep(3)

        # Fetch from inside the SAME origin/browser context.
        script = """
        const done = arguments[0];
        fetch('/data/Pets.json', {
            method: 'GET',
            credentials: 'include',
            cache: 'no-store'
        })
        .then(async r => {
            const text = await r.text();
            done({ok:r.ok,status:r.status,text:text});
        })
        .catch(e => done({ok:false,status:0,error:String(e)}));
        """
        result = driver.execute_async_script(script)

        if not result.get("ok"):
            raise RuntimeError("Elve browser fetch failed: HTTP %s %s" %
                               (result.get("status"), result.get("error","")))

        return json.loads(result["text"])
    finally:
        driver.quit()

def refresh_cache():
    try:
        data = get_live_data()
        CACHE["data"] = data
        CACHE["time"] = time.time()
        CACHE["error"] = None
        print("Elvebredd data loaded successfully.")
    except Exception as e:
        CACHE["error"] = str(e)
        print("ELVE ERROR:", e)

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        rel = path.split("?",1)[0].split("#",1)[0].lstrip("/") or "index.html"
        return str(ROOT / rel)

    def send_json(self, status, obj):
        raw=json.dumps(obj,ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path.startswith("/api/elve"):
            force="refresh=1" in self.path
            if force or CACHE["data"] is None or time.time()-CACHE["time"] > 30:
                refresh_cache()
            if CACHE["data"] is not None:
                self.send_json(200,CACHE["data"])
            else:
                self.send_json(502,{"error":CACHE["error"] or "Unknown Elve error"})
            return
        super().do_GET()

def open_page():
    time.sleep(1.2)
    webbrowser.open("http://127.0.0.1:8765/")

if __name__=="__main__":
    os.chdir(ROOT)
    print("="*65)
    print("Adopt Me Elvebredd Browser Bridge")
    print("This uses Chrome/Selenium to fetch Elvebredd from browser context.")
    print("Open: http://127.0.0.1:8765/")
    print("="*65)
    threading.Thread(target=open_page,daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1",8765),Handler).serve_forever()
