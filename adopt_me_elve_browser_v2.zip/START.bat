@echo off
title Adopt Me Elvebredd Browser Bridge
cd /d "%~dp0"
echo Installing/checking Selenium...
python -m pip install selenium
if errorlevel 1 (
  echo.
  echo Selenium install failed.
  pause
  exit /b
)
echo.
echo Starting...
python server.py
echo.
echo Server stopped or crashed.
pause
