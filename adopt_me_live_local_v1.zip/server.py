from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from pathlib import Path
import json
import time
import os
import webbrowser
import threading

ROOT = Path(__file__).resolve().parent
ELVE_URL = "https://www.elvebredd.com/data/Pets.json"
CACHE = {"time": 0, "data": None}
CACHE_SECONDS = 10

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        path = path.split("?", 1)[0].split("#", 1)[0]
        rel = path.lstrip("/") or "index.html"
        return str(ROOT / rel)

    def do_GET(self):
        if self.path.startswith("/api/elve"):
            self.handle_elve()
            return
        super().do_GET()

    def handle_elve(self):
        now = time.time()
        if CACHE["data"] is not None and now - CACHE["time"] < CACHE_SECONDS:
            self.send_json(200, CACHE["data"])
            return

        try:
            req = Request(
                ELVE_URL,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/json,text/plain,*/*",
                    "Referer": "https://www.elvebredd.com/adopt-me-calculator",
                },
            )
            with urlopen(req, timeout=15) as r:
                raw = r.read().decode("utf-8", errors="replace")
                data = json.loads(raw)

            CACHE["time"] = now
            CACHE["data"] = data
            self.send_json(200, data)

        except Exception as e:
            self.send_json(502, {"ok": False, "error": str(e)})

    def send_json(self, status, obj):
        payload = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

def open_browser():
    time.sleep(1)
    webbrowser.open("http://127.0.0.1:8765/")

if __name__ == "__main__":
    os.chdir(ROOT)
    threading.Thread(target=open_browser, daemon=True).start()
    print("=" * 58)
    print("Adopt Me local server")
    print("Open: http://127.0.0.1:8765/")
    print("Close this window to stop the server.")
    print("=" * 58)
    ThreadingHTTPServer(("127.0.0.1", 8765), Handler).serve_forever()