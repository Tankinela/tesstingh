@echo off
title Adopt Me Live Values
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py server.py
    goto :eof
)

where python >nul 2>nul
if %errorlevel%==0 (
    python server.py
    goto :eof
)

echo.
echo Python was not found.
echo Install Python from https://www.python.org/downloads/
echo During setup, tick "Add Python to PATH".
echo.
pause