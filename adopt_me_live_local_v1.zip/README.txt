HOW TO RUN
==========

1. Extract this whole folder somewhere.
2. Double-click START.bat
3. Keep the black command window open.
4. Your browser should open automatically at:
   http://127.0.0.1:8765/

The local Python server fetches:
https://www.elvebredd.com/data/Pets.json

The webpage itself only talks to:
http://127.0.0.1:8765/api/elve

This avoids browser CORS blocking.

If the browser does not open automatically, manually open:
http://127.0.0.1:8765/

Close the black server window when you are done.